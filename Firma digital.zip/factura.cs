﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security;
using System.Text;
using System.Threading.Tasks;
using BillingSystem;

namespace ConsoleApp1
{
    public class Factura
    {
        public string Id { get; set; }
        public decimal Total { get; set; }
        private CertificadoDigital certificadoDigital;

        
        public Factura(string id, decimal total, CertificadoDigital certificadoDigital)
        {
            Id = id;
            Total = total;
            this.certificadoDigital = certificadoDigital;
        }

   
        public string GenerarFacturaFirmada()
        {
            string facturaXML = $"<Factura><ID>{Id}</ID><Total>{Total}</Total></Factura>";
            string firma = certificadoDigital.FirmarDocumento(facturaXML);
            return $"{facturaXML}<Signature>{firma}</Signature>";
        }
    }

    class Program
    {
        private static SecureString CreateSecureString(string plainText)
        {
            SecureString secureString = new SecureString();
            foreach (char c in plainText)
            {
                secureString.AppendChar(c);
            }
            secureString.MakeReadOnly();
            return secureString;
        }

        static void Main(string[] args)
        {
            string certificatePath = @"D:\certi.pfx";
            SecureString password = CreateSecureString("password"); 

            
            var certificadoDigital = new CertificadoDigital(certificatePath, password);
            certificadoDigital.CargarCertificado();

           
            var factura = new Factura("12345", 1500.00m, certificadoDigital);
            string facturaFirmada = factura.GenerarFacturaFirmada();

            Console.WriteLine("Factura XML con Firma:\n" + facturaFirmada);
        }
    }
}