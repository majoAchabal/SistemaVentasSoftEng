using System;
using System.Security;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace BillingSystem
{
    // Class to handle digital certificate loading and signing
    public class CertificadoDigital
    {
        private string rutaCertificado;  // Path to the PFX file
        private SecureString contrase�a; // Password for the PFX file
        private X509Certificate2? certificado; // Loaded certificate object

        // Constructor: Initializes certificate path and password
        public CertificadoDigital(string rutaCertificado, SecureString contrase�a)
        {
            this.rutaCertificado = rutaCertificado;
            this.contrase�a = contrase�a;
        }

        // Method: Load the certificate from the PFX file
        public void CargarCertificado()
        {
            certificado = new X509Certificate2(rutaCertificado, contrase�a, X509KeyStorageFlags.MachineKeySet);
        }

        // Method: Signs the provided XML data and returns the digital signature as Base64
        public string FirmarDocumento(string data)
        {
            if (certificado == null)
                throw new InvalidOperationException("Certificado no cargado. Llama a CargarCertificado primero.");

            byte[] dataToSign = Encoding.UTF8.GetBytes(data);
            using (var rsa = certificado.GetRSAPrivateKey())
            {
                if (rsa == null)
                    throw new InvalidOperationException("No se pudo obtener la clave privada del certificado.");

                byte[] signedData = rsa.SignData(dataToSign, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
                return Convert.ToBase64String(signedData);
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            SecureString password = new SecureString();
            foreach (char c in "password")
            {
                password.AppendChar(c);
            }

            CertificadoDigital certificadoDigital = new CertificadoDigital(@"D:\certi.pfx", password);
            certificadoDigital.CargarCertificado();

            string data = "<xml>data</xml>";
            string firma = certificadoDigital.FirmarDocumento(data);

            Console.WriteLine("Firma digital: " + firma);
        }
    }
}
