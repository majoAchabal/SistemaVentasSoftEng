﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using QRCoder;
using System.Windows.Forms;

namespace codigosQR
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnGenerarQR_Click(object sender, EventArgs e)
        {
            string codigoFactura = txtCodigoFactura.Text;

            if (codigoFactura.Length != 8 || !int.TryParse(codigoFactura, out _))
            {
                MessageBox.Show("El código de factura debe tener exactamente 8 dígitos numéricos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Bitmap qrImagen = GenerarCodigoQR(codigoFactura);

            picQRCode.Image = qrImagen;
        }

        private Bitmap GenerarCodigoQR(string codigoFactura)
        {
            using (QRCodeGenerator qrGenerator = new QRCodeGenerator())
            {
                QRCodeData qrCodeData = qrGenerator.CreateQrCode(codigoFactura, QRCodeGenerator.ECCLevel.Q);
                using (QRCode qrCode = new QRCode(qrCodeData))
                {
                    Bitmap qrCodeImage = qrCode.GetGraphic(200);
                    return qrCodeImage;
                }
            }
        }
    }
}
